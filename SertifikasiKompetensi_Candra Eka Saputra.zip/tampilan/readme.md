

#  Penjelasan Folder
1. Pada website ini terdapat folder assets yang terdiri dari :
    a. folder boostrap yang berfungsi untuk membuat website responsive dan mobile-first.
    b. folder css yang berfungsi untuk membantu mengubah dan menambahkan, baik teks, gambar, hingga latar belakang sebuah halaman website yang dibuat
    c. folder img berisi gambar yang digunakan pada bagian jenis beasiswa
    d. folder js yang berfungsi untuk mengembangkan web agar lebih interaktif 
    e. folder uploads berisi tentang file berformat pdf yang sudah di inputkan pada web di menu daftar
2. selanjutnya file index.php yang berfungsi sebagai tampilan utama website
3. file daftar.php yang berfungsi sebagai tampilan form inputan dalam pendaftaran beasiswa
4. file hasil.php berfungsi untuk menampilkan hasil dari data yang sudah di input sebelumnya pada menu daftar dan mengkoneksikan ke dalam database yang telah dibuat untuk menyimpan data yang sebelumnya sudah di inputkan
5. file getdata.php berfungsi untuk menampilkan semua data yang sudah masuk pada database
6. file konekgrafik.php yang berfungsi untuk mengkoneksikan database yang ada untuk ditampilkan ke grafik 
7. readme.md adalah file ini yang sedang dibuka berisikan penjelasan setiap file
